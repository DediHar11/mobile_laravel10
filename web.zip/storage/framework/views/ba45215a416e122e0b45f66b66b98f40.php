<!-- Libraries Stylesheet -->
<link href="<?php echo e(asset('load/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('load/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css')); ?>" rel="stylesheet" />

<!-- Customized Bootstrap Stylesheet -->
<link href="<?php echo e(asset('load/css/bootstrap.min.css')); ?>" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="<?php echo e(asset('load/css/style.css')); ?>" rel="stylesheet"><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/layouts/style.blade.php ENDPATH**/ ?>