<?php $__env->startSection('content'); ?>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-arrow-circle-down text-success" aria-hidden="true" style="font-size:40px"></i>
                <div class="ms-3">
                    <p class="mb-2">Barang masuk</p>
                    <h6 class="mb-0"><?php echo e($b); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-arrow-circle-up text-danger" aria-hidden="true" style="font-size:40px"></i>
                <div class="ms-3">
                    <p class="mb-2">Barang keluar</p>
                    <h6 class="mb-0"><?php echo e($d); ?></h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-user-circle text-primary" aria-hidden="true" style="font-size:40px"></i>
                <div class="ms-3">
                    <p class="mb-2">Total User Admin</p>
                    <h6 class="mb-0"><?php echo e($a); ?></h6>
                </div>
            </div>
        </div>
        
    </div>
</div>
<!-- Sale & Revenue End -->


<!-- Recent Sales Start -->
<div class="container-fluid pt-4 px-4">
    <div class="bg-light text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h6 class="mb-0">Barang masuk hari ini</h6>
            <!-- <a href="#" class="btn btn-sm btn-outline-info"><i class="fa fa-print" aria-hidden="true"></i> Cetak</a> -->
        </div>
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0">
                <thead>
                    <tr class="text-dark">
                        <th>No</th>
                        <th scope="col">Nama Barang</th>
                        <th scope="col">Merek</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Keterangan</th>
                        <th scope="col">Stok</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no=1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($d->nama_barang); ?></td>
                        <td><?php echo e($d->merek->merek); ?></td>
                        <td><?php echo e($d->kategori->kategori); ?></td>
                        <td><?php echo e($d->keterangan); ?></td>
                        <td><?php echo e($d->stok); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Recent Sales End -->

<!-- <div class="container-fluid pt-4 px-4">
    <div class="bg-light text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h6 class="mb-0">Barang keluar hari ini</h6>
            <a href="#" class="btn btn-sm btn-outline-info"><i class="fa fa-print" aria-hidden="true"></i> Cetak</a>
        </div>
        <div class="table-responsive">
            <table class="table text-start align-middle table-bordered table-hover mb-0">
                <thead>
                    <tr class="text-dark">
                        <th>No</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Nama Barang</th>
                        <th scope="col">Merek</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Keterangan</th>
                        <th scope="col">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>1 Desember 2023</td>
                        <td>kulkas</td>
                        <td>panasi</td>
                        <td>elektronik</td>
                        <td>kulkas 200</td>
                        <td><a class="btn btn-sm btn-danger">22</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/beranda.blade.php ENDPATH**/ ?>