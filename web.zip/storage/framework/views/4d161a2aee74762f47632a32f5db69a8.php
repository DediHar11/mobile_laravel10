<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <h6 class="mb-0" style="text-align:left">Barang Masuk</h6><br>
            <div class="d-flex align-items-center justify-content-between mb-4">
                <a href="<?php echo e(route('tambahbarangmasuk')); ?>" class="btn btn-sm btn-outline-info"><i class="fa fa-plus"></i> Tambah</a>
                <a href="<?php echo e(route('cetak_bm')); ?>" target="_blank" class="btn btn-sm btn-outline-success"><i class="fa fa-print" aria-hidden="true"></i> Cetak</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th>No</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Nama Barang</th>
                            <th scope="col">Merek</th>
                            <th scope="col">Kategori</th>
                            <th scope="col">Keterangan</th>
                            <th scope="col">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no=1;
                        ?>
                        <?php $__currentLoopData = $barangmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($no++); ?></td>
        <td><?php echo e($d->tanggal); ?></td>
        <td><?php echo e($d->nama_barang); ?></td>
        <td><?php echo e($d->merek); ?></td>
        <td><?php echo e($d->kategori); ?></td>
        <td><?php echo e($d->keterangan); ?></td>
        <td><?php echo e($a[$key]); ?></td>
        <td><a class="btn btn-sm btn-success"><?php echo e($d->jumlah); ?></a></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/transaksi/barangmasuk.blade.php ENDPATH**/ ?>