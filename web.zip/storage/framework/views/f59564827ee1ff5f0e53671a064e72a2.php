<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-10">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Tambah Barang Masuk</h6>
                    <form action="<?php echo e(route('storebarangmasuk')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="date" class="form-control" name="tanggal" id="floatingPassword" required>
                            <?php if($errors->has('??')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('??')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingPassword">Tanggal</label>
                        </div>
                        
                        <div class="form-floating mb-3">
                            <select class="form-select" id="floatingSelect" name="barang_id"
                                aria-label="Floating label select example" required>
                                <option selected>-- Pilih Barang --</option>
                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->nama_barang); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('barang_id')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('barang_id')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingSelect">Nama Barang</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="jumlah" id="floatingPassword"
                                placeholder="Jumlah" required>
                            <?php if($errors->has('jumlah')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('jumlah')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingPassword">Jumlah</label>
                        </div>

                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Isi keterangan" name="keterangan" id="floatingTextarea"
                                style="height: 150px;" required></textarea>
                            <?php if($errors->has('keterangan')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('keterangan')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingTextarea">Keterangan</label>
                        </div><br>
                        <a onclick="goBack()" class="btn btn-sm btn-outline-secondary">Batal</a>
                        <button class="btn btn-sm btn-outline-success" type="submit">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/transaksi/tambahbarangmasuk.blade.php ENDPATH**/ ?>