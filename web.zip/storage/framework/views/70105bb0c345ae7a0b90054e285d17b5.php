<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-10">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Tambah Merek</h6>
                    <form action="<?php echo e(route('store_merek')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="merek" id="floatingPassword"
                                placeholder="Nama merek">
                            <?php if($errors->has('merek')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('merek')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingPassword">Nama Merek</label>
                        </div>
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Isi keterangan" type="text" name="keterangan" id="floatingTextarea"
                                style="height: 150px;"></textarea>
                            <?php if($errors->has('keterangan')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('keterangan')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingTextarea">Keterangan</label>
                        </div><br>
                        <a onclick="goBack()" class="btn btn-sm btn-outline-secondary">Batal</a>
                        <button type="submit" class="btn btn-sm btn-outline-success">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/master/tambahmerek.blade.php ENDPATH**/ ?>