<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-10">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Tambah Barang</h6>
                    <form action="<?php echo e(route('store_barang')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" name="nama_barang" id="floatingPassword"
                                placeholder="Nama barang">
                            <?php if($errors->has('nama_barang')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('nama_barang')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingPassword">Nama Barang</label>
                        </div>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="floatingSelect" name="merek_id"
                                aria-label="Floating label select example">
                                <option selected>-- Pilih Barang --</option>
                                <?php $__currentLoopData = $merek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->merek); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('merek_id')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('merek_id')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingSelect">Merek Barang</label>
                        </div>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="floatingSelect" name="kategori_id"
                                aria-label="Floating label select example">
                                <option selected>-- Pilih Kategori --</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('kategori_id')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('kategori_id')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingSelect">Kategori Barang</label>
                        </div>
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Isi keterangan" name="keterangan" id="floatingTextarea"
                                style="height: 150px;"></textarea>
                            <?php if($errors->has('keterangan')): ?>
                                <span class="text-danger small">
                                    <p><?php echo e($errors->first('keterangan')); ?></p>
                                </span>
                            <?php endif; ?>
                            <label for="floatingTextarea">Keterangan</label>
                        </div><br>
                        <a onclick="goBack()" class="btn btn-sm btn-outline-secondary">Batal</a>
                        <button class="btn btn-sm btn-outline-success" type="submit">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah D4\Tugas\web\mobile_laravel10\resources\views/master/tambahbarang.blade.php ENDPATH**/ ?>